# ZOVA Android APK

This project wraps the supplied single-file ZOVA HTML app in an Android WebView.

## Build locally
Requires JDK 17, Android SDK 36 and Gradle 8.13.

`gradle assembleDebug`

APK: `app/build/outputs/apk/debug/app-debug.apk`

## Build without Android Studio
Push this folder to GitHub. The included GitHub Actions workflow builds the APK automatically and exposes it as a downloadable artifact.
